<?php

/**
 *
 * This is the HTML markup for the uTap2 Products Batch Page
 *
 * @package Utap2_Plugin
 * @subpackage uTap2Plugin/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
