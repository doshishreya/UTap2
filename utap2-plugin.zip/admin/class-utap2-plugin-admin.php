<?php

/**
 *
 * @package Utap2_Plugin
 * @subpackage uTap2Plugin/includes
 *
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 *
 * @since      1.0.0
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 * @author     Peter R Stanley (WideOpen Technologies <peter@wideopentech.com>
 */

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


class Utap2_Plugin_Admin
{

    private string $plugin_name;
    private string $version;

    public function __construct( string $plugin_name, string $version ) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    public function admin_menu()
    {
        add_menu_page(
            "uTap2 Product Batches",
            "uTap2 Product Batches",
            "administrator",
            "utap2_products",
            array( __CLASS__, 'utap2_products_page_html' ),
            "dashicons-id" ,
            20
        );
    }



    public function enqueue_styles()
    {

        wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/utap2-plugin-admin.css', array(), $this->version, 'all' );
    }

    public function enqueue_scripts()
    {

        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/utap2-plugin-admin.js', array( 'jquery' ), $this->version, false );
    }

    public static function utap2_products_page_html()
    {

        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">uTap2 Products</h1>';
        echo '<button type="button" class="page-title-action utap2-plugin create-batch-button">Create Batch</button>';
        echo '<hr class="wp-header-end"/>';

        static::create_batch_form();



        $table = new Utap2_Plugin_Admin_List_Table([ 'screen' => get_current_screen() ]);
        $pagenum = $table->get_pagenum();
        $doaction = $table->current_action();

        $table->prepare_items();

        echo $table->search_box([], 'post');
        echo $table->views();

        echo $table->display();


        if ($table->has_items()) {
            echo $table->inline_edit();
        }

        ?>
        <div id="my-content-id" style="display:none;">
            This is my hidden content! It will appear in ThickBox when the link is clicked.
        </div>
        <?php
        echo "</div>";
    }

    public static function create_batch_form()
    {
        $vendor_name = !empty($utap2_profile_data['vendor_name']) ? esc_html($utap2_profile_data['vendor_name']) : "";
        $cleanQuantity = !empty($utap2_profile_data['quantity']) ? esc_html($utap2_profile_data['quantity']) : 1;
        $nonce = wp_create_nonce("utap2-plugin-create-batch-form");

        ?>
<div class='utap2-plugin-new-batch-form-section' style="display: none;">
    <form class="utap2-form">
        <div class='form-field'>
            <label for='vendor_name'><?php _e('Vendor Name',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
            <input type='text' class='input-text input-vendor_name' name='vendor_name' id='vendor_name' value='<?php echo $vendor_name; ?>'>
            <div class="form-feedback input-vendor_name"></div>
        </div>
        <div class='form-field'>
            <label for='quantity'><?php _e('Quantity',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
            <input type='number' class='input-text input-quantity' name='quantity' id='quantity' min='1' value='<?php echo $cleanQuantity; ?>'>
            <div class="form-feedback input-quantity"></div>
        </div>
        <div class='form-field'>
            <label for='quantity'><?php _e('Product Type',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
            <select class="input-text input-product_type" name="product_type" id="product_type" required>
                <option value="" <?php empty($utap2_profile_data['product_type']) ? 'selected=selected' : ''; ?> ><?php _e('Please choose an option',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
                <option value="card" <?php echo !empty($utap2_profile_data['product_type']) && $utap2_profile_data['product_type'] == 'card' ? 'selected=selected' : ''; ?>><?php _e('Card',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
                <option value="tag" <?php echo !empty($utap2_profile_data['product_type']) && $utap2_profile_data['product_type'] == 'tag' ? 'selected=selected' : ''; ?>><?php _e('Tag',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
            </select>
            <div class="form-feedback input-product_type"></div>
        </div>
        <button type="button" class="utap2-plugin-process-batch-button">Process Batch</button>
    </form>
</div>
        <?php
    }

    public static function create_batch_form_modal()
    {
        $vendor_name = !empty($utap2_profile_data['vendor_name']) ? esc_html($utap2_profile_data['vendor_name']) : "";
        $cleanQuantity = !empty($utap2_profile_data['quantity']) ? esc_html($utap2_profile_data['quantity']) : 1;
        $nonce = wp_create_nonce("utap2-plugin-create-batch-form");

        ?>
        <div class="utap2-plugin utap2-plugin-modal">
            <div class="modal-background"></div>
            <div class='modal'>
                <form class="utap2-form">
                    <div class='form-field'>
                        <label for='vendor_name'><?php _e('Vendor Name',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
                        <input type='text' class='input-text input-vendor_name' name='vendor_name' id='vendor_name' value='<?php echo $vendor_name; ?>'>
                        <div class="form-feedback input-vendor_name"></div>
                    </div>
                    <div class='form-field'>
                        <label for='quantity'><?php _e('Quantity',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
                        <input type='number' class='input-text input-quantity' name='quantity' id='quantity' min='1' value='<?php echo $cleanQuantity; ?>'>
                        <div class="form-feedback input-quantity"></div>
                    </div>
                    <div class='form-field'>
                        <label for='quantity'><?php _e('Product Type',WP_UTAP2_PROFILE_TEXTDOMAIN); ?> &nbsp;<span class='required'>*</span></label>
                        <select class="input-text input-product_type" name="product_type" id="product_type" required>
                            <option value="" <?php empty($utap2_profile_data['product_type']) ? 'selected=selected' : ''; ?> ><?php _e('Please choose an option',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
                            <option value="card" <?php echo !empty($utap2_profile_data['product_type']) && $utap2_profile_data['product_type'] == 'card' ? 'selected=selected' : ''; ?>><?php _e('Card',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
                            <option value="tag" <?php echo !empty($utap2_profile_data['product_type']) && $utap2_profile_data['product_type'] == 'tag' ? 'selected=selected' : ''; ?>><?php _e('Tag',WP_UTAP2_PROFILE_TEXTDOMAIN); ?></option>
                        </select>
                        <div class="form-feedback input-product_type"></div>
                    </div>
                    <button type="button" class="utap2-plugin-process-batch-button">Process Batch</button>
                </form>
            </div>
        </div>

        <?php
    }

    public static function ajax_process_batch()
    {
		set_time_limit(600);
        $results = Utap2_Product::createBatch($_POST['vendor_name'], $_POST['product_type'], $_POST['quantity']);
        wp_send_json_success();
    }

    public static function download_utap2_products_batch()
    {

        if (!isset($_GET['page']) || $_GET['page'] !== "utap2_products"
            || !isset($_GET['download']) || $_GET['download'] !== 'utap2_batch'
            || !isset($_GET['batch']) || strlen($_GET['batch']) === 0) {
            return;
        }

        $batch = $_GET['batch'];

        $items = Utap2_Product::getBatchItems($batch);
        $spreadsheet = new Spreadsheet();
        // Set document properties
        $spreadsheet->getProperties()
            ->setCreator('Your Name')
            ->setLastModifiedBy('Your Name')
            ->setTitle('Sample Excel Document')
            ->setSubject('Sample Excel Document')
            ->setDescription('A sample Excel document for demonstration purposes');

        // Add data to the spreadsheet
        $spreadsheet->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Batch')
            ->setCellValue('B1', 'Vendor')
            ->setCellValue('C1', 'Product Type')
            ->setCellValue('D1', 'Hash')
            ->setCellValue('E1', 'Card Hash URL')
		    ->setCellValue('F1', 'QR Code Hash URL');

        $rowId = 2;
        foreach ($items as $row) {

            $hashUrl = get_site_url()."/utap2_products/{$row->hash}";
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue("A$rowId", $row->batch)
                ->setCellValue("B$rowId", $row->vendor_name)
                ->setCellValue("C$rowId", $row->product_type)
                ->setCellValue("D$rowId", $row->hash)
                ->setCellValue("E$rowId", $hashUrl)
				->setCellValue("F$rowId", $hashUrl);
            $rowId++;
        }

        // Set column widths
        $spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(10);

        // Set the Content-Type header for Excel (.xlsx) files
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        // Set the Content-Disposition header to prompt the user to download the file
        header('Content-Disposition: attachment;filename="uTap2_batch.xlsx"');
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }

}