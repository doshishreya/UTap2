let uTap2_Form_Errors = {
    hasErrors: false,
    errors: {
        vendor_name: [],
        quantity: [],
        product_type: [],
    }
}

jQuery(document).ready(function () {
    'use strict';

    utap2_form_render_errors()

    jQuery(".utap2-plugin.create-batch-button").click(function () {

        jQuery(".utap2-plugin-new-batch-form-section").css('display', 'block')
    })

    jQuery(".utap2-plugin-process-batch-button").click(function () {

        let vendor_name = jQuery(".utap2-form .input-vendor_name").val()
        let quantity = jQuery(".utap2-form .input-quantity").val()
        let product_type = jQuery(".utap2-form .input-product_type option:selected").val()

        uTap2_Form_Errors = {
            hasErrors: false,
            errors: {
                vendor_name: [],
                quantity: [],
                product_type: [],
            }
        }

        /** Validation **/
        if (vendor_name.length === 0) {
            uTap2_Form_Errors.errors.vendor_name.push("Vendor Name is required")
            uTap2_Form_Errors.hasErrors = true
        }
        if (quantity < 1) {
            uTap2_Form_Errors.errors.quantity.push("Quantity needs to be a minimum of 1")
            uTap2_Form_Errors.hasErrors = true
        }
        if (product_type.length === 0) {
            uTap2_Form_Errors.errors.product_type.push("You need to select a Product Type.")
            uTap2_Form_Errors.hasErrors = true
        }

        if (!['card', 'tag'].includes(product_type)) {
            uTap2_Form_Errors.errors.product_type.push("Product Type needs to be a Card or Tag only.")
            uTap2_Form_Errors.hasErrors = true
        }

        if (uTap2_Form_Errors.hasErrors) {
            utap2_form_render_errors()
            return
        }

        /** Processing Batch **/
        jQuery.ajax({
            type : "post",
            dataType : "json",
            url: "/wp-admin/admin-ajax.php",
            data: {
                action: "process_batch",
                nonce: jQuery(this).attr("data-nonce"),
                vendor_name,
                quantity,
                product_type
            },
            success: function (response) {
                console.log(response)
                window.location.reload()
            },
            error: function (response) {
                console.log(response)
            }
        })
    })
})

function utap2_form_render_errors()
{

    Object.keys(uTap2_Form_Errors.errors).forEach(function(field) {
        if (uTap2_Form_Errors.errors[field].length > 0) {
            jQuery(`.form-feedback.input-${field}`).html(uTap2_Form_Errors.errors[field].join(' '))
        }
    })
}