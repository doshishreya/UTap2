<?php
/**
 * uTap2 Plugin
 *
 * Plugin Name:       uTap2 Plugin
 * Description:       Handle the basics with this plugin.
 * Version:           1.0.0
 * Requires at least: 6.3.2
 * Requires PHP:      7.3
 * Author:            WideOpen Technologies
 * Author URI:        https://wideopentech.com/
 * Text Domain:       utap2-plugin
 * Domain Path:       /languages
 */

require_once "vendor/autoload.php";

if ( ! defined( 'ABSPATH' ) || ! defined( 'WPINC' )  ) {
    exit; // Exit if accessed directly
}

/** Plugin Definitions **/
define( 'UTAP2_PLUGIN_VERSION', '1.0.0' );
define( 'UTAP2_PRODUCTS_TABLE', 'utap2_products' );
define( 'WP_UTAP2_PROFILE_TEXTDOMAIN', 'utap2-plugin');


function activate_utap2_plugin()
{

    require_once plugin_dir_path( __FILE__ ) . 'includes/class-utap2-plugin-activator.php';
    Utap2_Plugin_Activator::activate();
}

function deactivate_utap2_plugin()
{

    require_once plugin_dir_path( __FILE__ ) . 'includes/class-utap2-plugin-deactivator.php';
    Utap2_Plugin_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_utap2_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_utap2_plugin' );


require plugin_dir_path( __FILE__ ) . 'includes/class-utap2-plugin.php';
function run_utap2_plugin()
{
    $plugin = new Utap2_Plugin();
    $plugin->run();
}

run_utap2_plugin();