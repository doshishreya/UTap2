<?php

/**
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 * @author     Peter R Stanley (WideOpen Technologies <peter@wideopentech.com>
 */
class Utap2_Plugin_i18n
{

    public function load_plugin_textdomain()
    {

        load_plugin_textdomain(
            'plugin-name',
            false,
            dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
        );

    }



}