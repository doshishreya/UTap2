<?php

/**
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 * @author     Peter R Stanley (WideOpen Technologies <peter@wideopentech.com>
 */
class Utap2_Plugin_Deactivator
{

    public static function deactivate()
    {

    }

}