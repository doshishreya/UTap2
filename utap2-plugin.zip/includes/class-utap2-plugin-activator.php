<?php

/**
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 * @author     Peter R Stanley (WideOpen Technologies <peter@wideopentech.com>
 */
class Utap2_Plugin_Activator
{

    public static function activate()
    {
        $installedVersion = get_option('utap2-plugin');
        if (!$installedVersion) {

            if ( defined( 'UTAP2_PLUGIN_VERSION' ) ) {
                $pluginVersion = UTAP2_PLUGIN_VERSION;
            } else {
                $pluginVersion = '1.0.0';
            }
            add_option( 'utap2-plugin', $pluginVersion );

            self::generate_utap2_products_table();
        }

    }

    private static function generate_utap2_products_table()
    {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        @set_time_limit( 0 );
        global $wpdb;
        $charset_collate = '';

        if ( $wpdb->has_cap( 'collation' ) ) {
            if ( ! empty( $wpdb->charset ) ) {
                $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
            }
            if ( ! empty( $wpdb->collate ) ) {
                $charset_collate .= " COLLATE $wpdb->collate";
            }
        }

        $createTableSql = "DROP TABLE IF EXISTS `{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE."`;
				CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE."` (
				`id` int NOT NULL AUTO_INCREMENT,
				`hash` varchar(255) NOT NULL,
				`profile_id` int NULL,
				`user_id` int NULL,
				`product_type` varchar(255) NOT NULL,
				`vendor_name` varchar(255) NOT NULL,
				`batch` varchar(255) NOT NULL,
				`batch_at` DATETIME NOT NULL,
				PRIMARY KEY (`id`)
			) {$charset_collate};";
        $data = dbDelta( $createTableSql );
    }

}
