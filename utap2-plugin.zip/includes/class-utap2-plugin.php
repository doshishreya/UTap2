<?php

/**
 *
 * @package Utap2_Plugin
 * @subpackage uTap2Plugin/includes
 *
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Utap2_Plugin
 * @subpackage Utap2_Plugin/includes
 * @author     Peter R Stanley (WideOpen Technologies <peter@wideopentech.com>
 */

class Utap2_Plugin
{

    protected Utap2_Plugin_Loader $loader;
    protected string $plugin_name;
    protected string $version;

    public function __construct() {
        if ( defined( 'UTAP2_PLUGIN_VERSION' ) ) {
            $this->version = UTAP2_PLUGIN_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'utap2-plugin';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();

    }

    private function load_dependencies()
    {

        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-utap2-plugin-loader.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-utap2-plugin-i18n.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-utap2-plugin-table.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-utap2-plugin-admin.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-utap2-plugin-public.php';

        $this->loader = new Utap2_Plugin_Loader();

    }

    private function set_locale() {

        $plugin_i18n = new Utap2_Plugin_i18n();

        $this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

    }

    private function define_admin_hooks() {

        $plugin_admin = new Utap2_Plugin_Admin( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        $this->loader->add_action( 'admin_menu', $plugin_admin, 'admin_menu' );
        $this->loader->add_action( 'wp_ajax_process_batch', $plugin_admin, 'ajax_process_batch' );
        $this->loader->add_action( 'plugins_loaded',$plugin_admin, 'download_utap2_products_batch');


    }

    private function define_public_hooks() {

        $plugin_public = new Utap2_Plugin_Public( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        //$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

        $this->loader->add_action( 'plugins_loaded', $plugin_public, 'utap2_plugin_init');
		$this->loader->add_action( 'wp', $plugin_public, 'utap2_plugin_set_cookie');
		
        //$this->loader->add_action( 'add_shortcode', $plugin_public, 'utap2_plugin_shortcodes');
        add_shortcode('utap2_plugin_edit_profile', array($plugin_public, 'utap2_plugin_edit_profile'));
		add_shortcode('utap2_plugin_profile_links', array($plugin_public, 'utap2_plugin_profile_links'));
		add_shortcode('utap2_plugin_profile_niche_list', array($plugin_public, 'utap2_plugin_profile_niche_list'));
		
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_loader() {
        return $this->loader;
    }

    public function get_version() {
        return $this->version;
    }

}