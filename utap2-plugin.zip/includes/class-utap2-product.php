<?php

class Utap2_Product
{

    // Static Functions
    public static function allBatches(): stdClass
    {

        global $wpdb;

        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;
        $orderby = ( isset( $_GET['orderby'] ) ) ? esc_sql( $_GET['orderby'] ) : 'id';
        $order = ( isset( $_GET['order'] ) ) ? esc_sql( $_GET['order'] ) : 'ASC';

        $baseSql = "SELECT 
	vendor_name,
    product_type,
	batch, 
	count(id) as batched_items, 
	SUM(CASE WHEN profile_id is not null then 1 else 0 end) as activated_items 
FROM {$table_name}
GROUP BY vendor_name, batch ";

        // query output_type will be an associative array with ARRAY_A.
        $totalEntries = $wpdb->get_results($baseSql);
        $data = $wpdb->get_results( "$baseSql ORDER BY $orderby $order", ARRAY_A  );

        return (object) [
            'data' => $data,
            'total' => count($totalEntries)
        ];
    }

    public static function findBatch($batch)
    {
        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;



    }

    public static function hashExists($hash)
    {

        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;

        $hash = esc_sql($hash);
        $query = $wpdb->prepare("SELECT id FROM $table_name WHERE hash = '%s'", $hash);
        $data = $wpdb->get_results( $query );

        return !empty($data);
    }

    public static function findBatchItemByHash($hash)
    {
        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;
        $hash = esc_sql($hash);

        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE hash = '%s'", $hash);
        $object = $wpdb->get_results( $query )[0] ?? false;

        $object->profile = null;
        if ($object->profile_id) {
			$profile = get_post((int) $object->profile_id);
			$object->profile = $profile;
        }
        return $object;

    }

    public static function getBatchItems(string $batch)
    {

        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;
        $batch = esc_sql($batch);

        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE batch = '%s'", $batch);
        return $wpdb->get_results( $query );

    }

    public static function createBatch(string $vendor_name, string $product_type, int $quantity = 1)
    {

        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;
        $results = [];

        $vendor_name = esc_sql($vendor_name);
        $product_type = esc_sql($product_type);
        $quantity = (int) esc_sql($quantity);
        $batch = 'batch_'.time();
        $batch_at = new DateTime("now");

        for ($i = 0; $i < $quantity; $i++) {

            $uniqueHashFound = false;
            while(!$uniqueHashFound) {
                $hash = wp_hash(time() + $i);

                $uniqueHashFound = !static::hashExists($hash);
            }

            $query = $wpdb->prepare("INSERT INTO $table_name (vendor_name, product_type, batch, batch_at, hash) VALUES(%s, %s, %s, %s, %s)",
                $vendor_name, $product_type, $batch, $batch_at->format("Y-m-d H:i:s"), $hash);

            $results[] = $wpdb->query($query);
        }

        return $results;

    }
	
	public static function linkProfileToProductByHash($profileId, $hash)
	{
		
        global $wpdb;
        $table_name = "{$wpdb->prefix}".UTAP2_PRODUCTS_TABLE;
		
		$query = $wpdb->prepare("UPDATE $table_name SET profile_id = %d WHERE hash = '%s'", $profileId, $hash);
        $results = $wpdb->query($query);
		
		return ($results > 0);
	}

}
